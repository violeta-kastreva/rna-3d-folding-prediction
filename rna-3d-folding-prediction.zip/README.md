# rna-3d-folding-prediction

RibonanzaNet Explained
https://www.kaggle.com/code/alejopaullier/stanford-rna-3d-ribonanzanet-explained

RibonanzaNet 2.0-DDPM Explained
https://www.kaggle.com/code/siddhantoon/ribonanzanet-2-0-ddpm-explained

AlphaFold Paper
https://www.uvio.bio/alphafold-architecture/AlphaFold-Supplementary-Information.pdf?utm_source=chatgpt.com